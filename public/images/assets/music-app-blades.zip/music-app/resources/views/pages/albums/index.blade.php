@extends('layouts.app')

@section('title', 'Albums')

@section('styles')
<style>
.album-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 16px;
  margin-top: 20px;
}
.album-card {
  background: #1a1a1a;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  overflow: hidden;
  transition: border-color .2s, transform .2s;
}
.album-card:hover { border-color: rgba(255,59,48,.4); transform: translateY(-2px); }
.album-art {
  width: 100%; aspect-ratio: 1;
  background: #1e1e1e;
  display: flex; align-items: center; justify-content: center;
  font-size: 2.8rem; overflow: hidden;
}
.album-art img { width:100%; height:100%; object-fit:cover; }
.album-body { padding: 12px 14px 14px; }
.album-title {
  font-family: 'Syne', sans-serif; font-size: .88rem; font-weight: 700;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  margin-bottom: 3px;
}
.album-artist { font-size: .75rem; color: rgba(255,255,255,.35); margin-bottom: 8px; }
.album-meta { font-size: .72rem; color: rgba(255,255,255,.2); }
.album-actions {
  display: flex; gap: 4px; justify-content: flex-end; margin-top: 10px;
}
.action-btn {
  background: none; border: none;
  color: rgba(255,255,255,.25); cursor: pointer;
  font-size: 15px; padding: 4px; border-radius: 6px;
  transition: color .18s, background .18s;
}
.action-btn:hover { color: #ff3b30; background: rgba(255,59,48,.1); }
</style>
@endsection

@section('content')

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <div class="search-bar" style="margin-bottom:0;width:280px">
    <i class="ti ti-search"></i>
    <input type="text" id="albumSearch" placeholder="Search albums or artists…">
  </div>
  <a href="{{ route('albums.create') }}" class="btn btn-primary">
    <i class="ti ti-plus" style="font-size:15px"></i>Add Album
  </a>
</div>

@if($albums->count())
  <div class="album-grid" id="albumGrid">
    @foreach($albums as $album)
      <div class="album-card"
           data-search="{{ strtolower($album->title . ' ' . $album->artist) }}">
        <div class="album-art"
             data-title="{{ $album->title }}"
             data-artist="{{ $album->artist }}">💿</div>
        <div class="album-body">
          <div class="album-title" title="{{ $album->title }}">{{ $album->title }}</div>
          <div class="album-artist">{{ $album->artist }}</div>
          <div class="album-meta">
            {{ $album->tracks_count ?? 0 }} tracks
            @if($album->release_year)
              &nbsp;·&nbsp; {{ $album->release_year }}
            @endif
          </div>
          <div class="album-actions">
            <a href="{{ route('albums.show', $album) }}" class="action-btn" title="View">
              <i class="ti ti-eye"></i>
            </a>
            <a href="{{ route('albums.edit', $album) }}" class="action-btn" title="Edit">
              <i class="ti ti-pencil"></i>
            </a>
            <form method="POST" action="{{ route('albums.destroy', $album) }}"
                  style="display:inline"
                  onsubmit="return confirm('Delete {{ addslashes($album->title) }}?')">
              @csrf @method('DELETE')
              <button type="submit" class="action-btn" title="Delete">
                <i class="ti ti-trash"></i>
              </button>
            </form>
          </div>
        </div>
      </div>
    @endforeach
  </div>
  <div style="margin-top:20px">{{ $albums->links() }}</div>
@else
  <div class="empty-state">
    <i class="ti ti-vinyl"></i>
    No albums yet.
  </div>
@endif
@endsection

@section('scripts')
<script>
// Search filter
document.getElementById('albumSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.album-card').forEach(card => {
    card.style.display = card.dataset.search.includes(q) ? '' : 'none';
  });
});

// iTunes album art
document.querySelectorAll('.album-art[data-title]').forEach(function (el) {
  const query = encodeURIComponent(el.dataset.title + ' ' + el.dataset.artist);
  fetch('https://itunes.apple.com/search?term=' + query + '&media=music&entity=album&limit=1')
    .then(r => r.json())
    .then(data => {
      if (data.results?.length) {
        const art = data.results[0].artworkUrl100.replace('100x100bb', '300x300bb');
        el.innerHTML = `<img src="${art}" alt="">`;
      }
    }).catch(() => {});
});
</script>
@endsection
