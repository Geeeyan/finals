@extends('layouts.app')

@section('title', 'Artists')

@section('styles')
<style>
.artist-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
  gap: 16px;
  margin-top: 20px;
}
.artist-card {
  background: #1a1a1a;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  padding: 20px 16px 14px;
  text-align: center;
  transition: border-color .2s, transform .2s;
}
.artist-card:hover { border-color: rgba(255,59,48,.4); transform: translateY(-2px); }
.artist-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  background: linear-gradient(135deg, #ff3b30 0%, #cc2e28 100%);
  display: flex; align-items: center; justify-content: center;
  font-family: 'Syne', sans-serif; font-size: 1.4rem; font-weight: 800;
  margin: 0 auto 12px; overflow: hidden;
}
.artist-avatar img { width: 100%; height: 100%; object-fit: cover; }
.artist-name {
  font-family: 'Syne', sans-serif; font-size: .9rem; font-weight: 700;
  margin-bottom: 4px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.artist-meta { font-size: .72rem; color: rgba(255,255,255,.3); margin-bottom: 12px; }
.artist-actions { display: flex; gap: 4px; justify-content: center; }
.action-btn {
  background: none; border: none;
  color: rgba(255,255,255,.25); cursor: pointer;
  font-size: 15px; padding: 5px 7px; border-radius: 6px;
  transition: color .18s, background .18s;
}
.action-btn:hover { color: #ff3b30; background: rgba(255,59,48,.1); }
</style>
@endsection

@section('content')

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <div class="search-bar" style="margin-bottom:0;width:280px">
    <i class="ti ti-search"></i>
    <input type="text" id="artistSearch" placeholder="Search artists…">
  </div>
  <a href="{{ route('artists.create') }}" class="btn btn-primary">
    <i class="ti ti-plus" style="font-size:15px"></i>Add Artist
  </a>
</div>

@if($artists->count())
  <div class="artist-grid" id="artistGrid">
    @foreach($artists as $artist)
      @php
        $initials = strtoupper(collect(explode(' ', trim($artist->name)))->map(fn($w) => $w[0])->take(2)->implode(''));
      @endphp
      <div class="artist-card"
           data-search="{{ strtolower($artist->name) }}">
        <div class="artist-avatar"
             data-name="{{ $artist->name }}">{{ $initials }}</div>
        <div class="artist-name" title="{{ $artist->name }}">{{ $artist->name }}</div>
        <div class="artist-meta">
          {{ $artist->tracks_count ?? 0 }} tracks
          @if(isset($artist->albums_count))
            &nbsp;·&nbsp; {{ $artist->albums_count }} albums
          @endif
        </div>
        <div class="artist-actions">
          <a href="{{ route('artists.show', $artist) }}" class="action-btn" title="View">
            <i class="ti ti-eye"></i>
          </a>
          <a href="{{ route('artists.edit', $artist) }}" class="action-btn" title="Edit">
            <i class="ti ti-pencil"></i>
          </a>
          <form method="POST" action="{{ route('artists.destroy', $artist) }}"
                style="display:inline"
                onsubmit="return confirm('Delete {{ addslashes($artist->name) }}?')">
            @csrf @method('DELETE')
            <button type="submit" class="action-btn" title="Delete">
              <i class="ti ti-trash"></i>
            </button>
          </form>
        </div>
      </div>
    @endforeach
  </div>
  <div style="margin-top:20px">{{ $artists->links() }}</div>
@else
  <div class="empty-state">
    <i class="ti ti-music-star"></i>
    No artists yet.
  </div>
@endif
@endsection

@section('scripts')
<script>
// Search filter
document.getElementById('artistSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.artist-card').forEach(card => {
    card.style.display = card.dataset.search.includes(q) ? '' : 'none';
  });
});

// iTunes artist image
document.querySelectorAll('.artist-avatar[data-name]').forEach(function (el) {
  const query = encodeURIComponent(el.dataset.name);
  fetch('https://itunes.apple.com/search?term=' + query + '&media=music&entity=musicArtist&limit=1')
    .then(r => r.json())
    .then(data => {
      // Use first result artwork from a song as proxy for the artist
      if (data.results?.length && data.results[0].artworkUrl100) {
        const art = data.results[0].artworkUrl100.replace('100x100bb','300x300bb');
        el.innerHTML = `<img src="${art}" alt="">`;
      }
    }).catch(() => {});
});
</script>
@endsection
