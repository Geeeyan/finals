@extends('layouts.app')

@section('title', 'Playlists')

@section('styles')
<style>
.playlist-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 14px;
  margin-top: 20px;
}
.playlist-card {
  background: #1a1a1a;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  overflow: hidden;
  transition: border-color .2s, transform .2s;
  cursor: pointer;
  text-decoration: none;
  display: block;
}
.playlist-card:hover { border-color: rgba(255,59,48,.4); transform: translateY(-2px); }
.playlist-cover {
  width: 100%; aspect-ratio: 1;
  background: linear-gradient(135deg, #1e1e1e 0%, #2a2a2a 100%);
  display: flex; align-items: center; justify-content: center;
  font-size: 2.5rem;
  position: relative; overflow: hidden;
}
.playlist-cover-grid {
  display: grid; grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
  width: 100%; height: 100%;
}
.playlist-cover-grid img {
  width: 100%; height: 100%; object-fit: cover;
}
.playlist-body { padding: 12px 14px 14px; }
.playlist-name {
  font-family: 'Syne', sans-serif; font-size: .9rem; font-weight: 700;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  margin-bottom: 4px;
}
.playlist-meta { font-size: .72rem; color: rgba(255,255,255,.3); }
.playlist-actions {
  display: flex; align-items: center; justify-content: space-between;
  margin-top: 10px;
}
.action-btn {
  background: none; border: none;
  color: rgba(255,255,255,.25); cursor: pointer;
  font-size: 15px; padding: 4px; border-radius: 6px;
  transition: color .18s, background .18s;
}
.action-btn:hover { color: #ff3b30; background: rgba(255,59,48,.1); }
.filter-row { display: flex; gap: 8px; margin-bottom: 0; }
.filter-btn {
  padding: 6px 14px; border-radius: 8px;
  font-size: .78rem; font-weight: 500;
  border: 1px solid rgba(255,255,255,.08);
  background: rgba(255,255,255,.05);
  color: rgba(255,255,255,.4);
  cursor: pointer; transition: all .18s;
}
.filter-btn.active, .filter-btn:hover {
  background: #ff3b30; border-color: #ff3b30; color: #fff;
}
</style>
@endsection

@section('content')

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <div style="display:flex;gap:8px" class="filter-row">
    <button class="filter-btn active" data-filter="all">All</button>
    <button class="filter-btn" data-filter="public">Public</button>
    <button class="filter-btn" data-filter="private">Private</button>
  </div>
  <div style="display:flex;gap:10px;align-items:center">
    <div class="search-bar" style="margin-bottom:0;width:220px">
      <i class="ti ti-search"></i>
      <input type="text" id="plSearch" placeholder="Search playlists…">
    </div>
    <a href="{{ route('playlists.create') }}" class="btn btn-primary">
      <i class="ti ti-plus" style="font-size:15px"></i>New Playlist
    </a>
  </div>
</div>

@if($playlists->count())
  <div class="playlist-grid" id="playlistGrid">
    @foreach($playlists as $pl)
      <div class="playlist-card-wrap"
           data-name="{{ strtolower($pl->name) }}"
           data-visibility="{{ $pl->is_public ? 'public' : 'private' }}">
        <div class="playlist-card">
          <div class="playlist-cover">
            @if($pl->tracks && $pl->tracks->count() >= 4)
              <div class="playlist-cover-grid">
                @foreach($pl->tracks->take(4) as $t)
                  <div style="background:#1e1e1e;display:flex;align-items:center;justify-content:center;font-size:1.2rem">🎵</div>
                @endforeach
              </div>
            @else
              🎧
            @endif
          </div>
          <div class="playlist-body">
            <div class="playlist-name">{{ $pl->name }}</div>
            <div class="playlist-meta">
              {{ $pl->tracks_count ?? 0 }} tracks
              &nbsp;·&nbsp;
              <span class="badge {{ $pl->is_public ? 'badge-active' : 'badge-info' }}"
                    style="font-size:.65rem;padding:2px 6px">
                {{ $pl->is_public ? 'Public' : 'Private' }}
              </span>
            </div>
            <div class="playlist-actions">
              <span style="font-size:.72rem;color:rgba(255,255,255,.2)">
                {{ $pl->user->name ?? 'Unknown' }}
              </span>
              <div>
                <a href="{{ route('playlists.edit', $pl) }}" class="action-btn" title="Edit">
                  <i class="ti ti-pencil"></i>
                </a>
                <form method="POST" action="{{ route('playlists.destroy', $pl) }}"
                      style="display:inline"
                      onsubmit="return confirm('Delete {{ addslashes($pl->name) }}?')">
                  @csrf @method('DELETE')
                  <button type="submit" class="action-btn" title="Delete">
                    <i class="ti ti-trash"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    @endforeach
  </div>
  <div style="margin-top:20px">{{ $playlists->links() }}</div>
@else
  <div class="empty-state">
    <i class="ti ti-playlist-off"></i>
    No playlists yet.
  </div>
@endif
@endsection

@section('scripts')
<script>
// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    const filter = this.dataset.filter;
    document.querySelectorAll('.playlist-card-wrap').forEach(card => {
      card.style.display =
        filter === 'all' || card.dataset.visibility === filter ? '' : 'none';
    });
  });
});

// Search
document.getElementById('plSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.playlist-card-wrap').forEach(card => {
    card.style.display = card.dataset.name.includes(q) ? '' : 'none';
  });
});
</script>
@endsection
