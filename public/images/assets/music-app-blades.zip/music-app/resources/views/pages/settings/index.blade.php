@extends('layouts.app')

@section('title', 'Settings')

@section('styles')
<style>
.settings-layout { display: grid; grid-template-columns: 200px 1fr; gap: 20px; }
.settings-nav { display: flex; flex-direction: column; gap: 2px; }
.settings-nav-item {
  display: flex; align-items: center; gap: 9px;
  padding: 9px 12px; border-radius: 10px;
  font-size: .83rem; font-weight: 500;
  color: rgba(255,255,255,.4);
  cursor: pointer; transition: all .18s;
  border: none; background: none; text-align: left; width: 100%;
}
.settings-nav-item i { font-size: 16px; }
.settings-nav-item:hover { background: rgba(255,255,255,.05); color: rgba(255,255,255,.75); }
.settings-nav-item.active { background: rgba(255,59,48,.12); color: #ff3b30; }
.settings-panel { display: none; }
.settings-panel.active { display: block; }
.form-group { margin-bottom: 20px; }
.form-label {
  display: block; font-size: .78rem; font-weight: 500;
  color: rgba(255,255,255,.5); margin-bottom: 8px;
  letter-spacing: .03em;
}
.form-input {
  width: 100%;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 10px;
  color: #fff;
  font-size: .85rem;
  padding: 10px 14px;
  outline: none;
  transition: border-color .18s;
  font-family: 'Inter', sans-serif;
}
.form-input:focus { border-color: rgba(255,59,48,.4); }
.form-input::placeholder { color: rgba(255,255,255,.2); }
textarea.form-input { resize: vertical; min-height: 90px; }
.toggle-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 0;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
.toggle-row:last-child { border-bottom: none; }
.toggle-info .toggle-title { font-size: .85rem; font-weight: 500; margin-bottom: 3px; }
.toggle-info .toggle-desc { font-size: .75rem; color: rgba(255,255,255,.3); }
.toggle {
  width: 40px; height: 22px;
  background: rgba(255,255,255,.1);
  border-radius: 11px; position: relative;
  cursor: pointer; transition: background .2s; flex-shrink: 0;
  border: none;
}
.toggle.on { background: #ff3b30; }
.toggle::after {
  content: ''; position: absolute;
  width: 16px; height: 16px; border-radius: 50%;
  background: #fff; top: 3px; left: 3px;
  transition: transform .2s;
}
.toggle.on::after { transform: translateX(18px); }
.divider { border: none; border-top: 1px solid rgba(255,255,255,.06); margin: 20px 0; }
.danger-zone {
  border: 1px solid rgba(255,59,48,.2);
  border-radius: 12px; padding: 16px 20px;
  margin-top: 20px;
}
.danger-title { font-size: .85rem; font-weight: 600; color: #ff3b30; margin-bottom: 4px; }
.danger-desc { font-size: .78rem; color: rgba(255,255,255,.35); margin-bottom: 14px; }
@media (max-width: 700px) {
  .settings-layout { grid-template-columns: 1fr; }
  .settings-nav { flex-direction: row; flex-wrap: wrap; }
}
</style>
@endsection

@section('content')

<div class="settings-layout">

  {{-- Settings nav --}}
  <div class="settings-nav">
    <button class="settings-nav-item active" data-panel="general">
      <i class="ti ti-adjustments-horizontal"></i>General
    </button>
    <button class="settings-nav-item" data-panel="appearance">
      <i class="ti ti-palette"></i>Appearance
    </button>
    <button class="settings-nav-item" data-panel="notifications">
      <i class="ti ti-bell"></i>Notifications
    </button>
    <button class="settings-nav-item" data-panel="security">
      <i class="ti ti-shield-lock"></i>Security
    </button>
    <button class="settings-nav-item" data-panel="storage">
      <i class="ti ti-database"></i>Storage
    </button>
  </div>

  {{-- Panels --}}
  <div>

    {{-- General --}}
    <div class="settings-panel active card" id="panel-general">
      <div class="card-header" style="margin-bottom:20px">
        <div class="card-title">General Settings</div>
      </div>
      <form method="POST" action="{{ route('settings.update') }}">
        @csrf @method('PATCH')
        <div class="form-group">
          <label class="form-label">App Name</label>
          <input class="form-input" type="text" name="app_name"
                 value="{{ old('app_name', $settings['app_name'] ?? 'MUS.IC') }}">
        </div>
        <div class="form-group">
          <label class="form-label">App Description</label>
          <textarea class="form-input" name="app_description">{{ old('app_description', $settings['app_description'] ?? '') }}</textarea>
        </div>
        <div class="form-group">
          <label class="form-label">Support Email</label>
          <input class="form-input" type="email" name="support_email"
                 value="{{ old('support_email', $settings['support_email'] ?? '') }}"
                 placeholder="support@example.com">
        </div>
        <div class="form-group">
          <label class="form-label">Max Upload Size (MB)</label>
          <input class="form-input" type="number" name="max_upload_mb"
                 value="{{ old('max_upload_mb', $settings['max_upload_mb'] ?? 50) }}"
                 min="1" max="500">
        </div>
        <button type="submit" class="btn btn-primary">
          <i class="ti ti-device-floppy" style="font-size:15px"></i>Save Changes
        </button>
      </form>
    </div>

    {{-- Appearance --}}
    <div class="settings-panel card" id="panel-appearance">
      <div class="card-header" style="margin-bottom:20px">
        <div class="card-title">Appearance</div>
      </div>
      <div class="form-group">
        <label class="form-label">Accent Color</label>
        <input class="form-input" type="color"
               value="{{ $settings['accent_color'] ?? '#ff3b30' }}"
               style="height:44px;padding:4px 8px;cursor:pointer">
      </div>
      <div class="form-group">
        <label class="form-label">Logo Text</label>
        <input class="form-input" type="text"
               value="{{ $settings['logo_text'] ?? 'MUS.IC' }}"
               placeholder="MUS.IC">
      </div>
      <button class="btn btn-primary" style="margin-top:4px">
        <i class="ti ti-device-floppy" style="font-size:15px"></i>Save Changes
      </button>
    </div>

    {{-- Notifications --}}
    <div class="settings-panel card" id="panel-notifications">
      <div class="card-header" style="margin-bottom:20px">
        <div class="card-title">Notification Settings</div>
      </div>
      @php
        $notifs = [
          ['new_user',      'New User Registered',  'Email me when a new user signs up'],
          ['new_track',     'New Track Uploaded',   'Email me when a track is uploaded'],
          ['weekly_report', 'Weekly Report',        'Receive a weekly analytics summary'],
          ['system_alerts', 'System Alerts',        'Critical system alerts and errors'],
        ];
      @endphp
      @foreach($notifs as [$key, $title, $desc])
        <div class="toggle-row">
          <div class="toggle-info">
            <div class="toggle-title">{{ $title }}</div>
            <div class="toggle-desc">{{ $desc }}</div>
          </div>
          <button class="toggle {{ ($settings['notif_'.$key] ?? true) ? 'on' : '' }}"
                  data-key="{{ $key }}"
                  onclick="this.classList.toggle('on')"></button>
        </div>
      @endforeach
      <button class="btn btn-primary" style="margin-top:20px">
        <i class="ti ti-device-floppy" style="font-size:15px"></i>Save Changes
      </button>
    </div>

    {{-- Security --}}
    <div class="settings-panel card" id="panel-security">
      <div class="card-header" style="margin-bottom:20px">
        <div class="card-title">Security</div>
      </div>
      <form method="POST" action="{{ route('password.update') }}">
        @csrf @method('PUT')
        <div class="form-group">
          <label class="form-label">Current Password</label>
          <input class="form-input" type="password" name="current_password"
                 placeholder="Enter current password" autocomplete="current-password">
        </div>
        <div class="form-group">
          <label class="form-label">New Password</label>
          <input class="form-input" type="password" name="password"
                 placeholder="Enter new password" autocomplete="new-password">
        </div>
        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input class="form-input" type="password" name="password_confirmation"
                 placeholder="Confirm new password" autocomplete="new-password">
        </div>
        <button type="submit" class="btn btn-primary">
          <i class="ti ti-lock" style="font-size:15px"></i>Update Password
        </button>
      </form>
      <hr class="divider">
      <div class="toggle-row">
        <div class="toggle-info">
          <div class="toggle-title">Two-Factor Authentication</div>
          <div class="toggle-desc">Add an extra layer of security to your account</div>
        </div>
        <button class="toggle {{ Auth::user()->two_factor_confirmed_at ? 'on' : '' }}"
                onclick="this.classList.toggle('on')"></button>
      </div>
    </div>

    {{-- Storage --}}
    <div class="settings-panel card" id="panel-storage">
      <div class="card-header" style="margin-bottom:20px">
        <div class="card-title">Storage & Media</div>
      </div>
      @php
        $usedMB   = $storageUsedMB  ?? 0;
        $totalMB  = $storageTotalMB ?? 10240;
        $usedPct  = min(round(($usedMB / $totalMB) * 100), 100);
      @endphp
      <div style="margin-bottom:20px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
          <span style="font-size:.82rem;color:rgba(255,255,255,.5)">Storage Used</span>
          <span style="font-size:.82rem;font-weight:600">
            {{ number_format($usedMB,1) }} MB / {{ number_format($totalMB) }} MB
          </span>
        </div>
        <div style="height:8px;background:rgba(255,255,255,.07);border-radius:4px;overflow:hidden">
          <div style="height:100%;width:{{ $usedPct }}%;background:#ff3b30;border-radius:4px;transition:width .5s"></div>
        </div>
        <div style="font-size:.72rem;color:rgba(255,255,255,.3);margin-top:6px">{{ $usedPct }}% used</div>
      </div>

      <div class="toggle-row">
        <div class="toggle-info">
          <div class="toggle-title">Auto-compress Uploads</div>
          <div class="toggle-desc">Compress audio files on upload to save space</div>
        </div>
        <button class="toggle on" onclick="this.classList.toggle('on')"></button>
      </div>
      <div class="toggle-row">
        <div class="toggle-info">
          <div class="toggle-title">Store Original Files</div>
          <div class="toggle-desc">Keep original files alongside compressed versions</div>
        </div>
        <button class="toggle" onclick="this.classList.toggle('on')"></button>
      </div>

      <div class="danger-zone">
        <div class="danger-title">Danger Zone</div>
        <div class="danger-desc">Clear all cached media files. This cannot be undone.</div>
        <button class="btn"
                style="background:rgba(255,59,48,.12);color:#ff3b30;border:1px solid rgba(255,59,48,.2)"
                onclick="return confirm('Clear all cached media?')">
          <i class="ti ti-trash" style="font-size:14px"></i>Clear Cache
        </button>
      </div>
    </div>

  </div>
</div>
@endsection

@section('scripts')
<script>
document.querySelectorAll('.settings-nav-item').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.settings-nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.settings-panel').forEach(p => p.classList.remove('active'));
    this.classList.add('active');
    document.getElementById('panel-' + this.dataset.panel).classList.add('active');
  });
});
</script>
@endsection
