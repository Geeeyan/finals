@extends('layouts.app')

@section('title', 'Users')

@section('styles')
<style>
.stats { display: grid; grid-template-columns: repeat(3,1fr); gap: 14px; margin-bottom: 24px; }
.stat-card { background:#161616; border:1px solid rgba(255,255,255,.07); border-radius:14px; padding:18px 20px; }
.stat-label { font-size:.72rem; color:rgba(255,255,255,.38); text-transform:uppercase; letter-spacing:.07em; margin-bottom:10px; }
.stat-val { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; letter-spacing:-.03em; margin-bottom:6px; }
.user-av {
  width: 34px; height: 34px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; font-weight: 700; flex-shrink: 0;
}
.role-select {
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 7px;
  color: rgba(255,255,255,.5);
  font-size: .75rem;
  padding: 4px 8px;
  cursor: pointer;
  outline: none;
}
.action-btn {
  background: none; border: none;
  color: rgba(255,255,255,.25);
  cursor: pointer; font-size: 16px;
  padding: 4px; border-radius: 6px;
  transition: color .18s, background .18s;
}
.action-btn:hover { color: #ff3b30; background: rgba(255,59,48,.1); }
@media (max-width:860px) { .stats { grid-template-columns: repeat(2,1fr); } }
</style>
@endsection

@section('content')

{{-- Stat cards --}}
<div class="stats">
  <div class="stat-card">
    <div class="stat-label">Total Users</div>
    <div class="stat-val">{{ number_format($totalUsers) }}</div>
    <span class="badge badge-up"><i class="ti ti-users" style="font-size:11px"></i>All time</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Admins</div>
    <div class="stat-val">{{ number_format($adminCount) }}</div>
    <span class="badge badge-admin"><i class="ti ti-shield" style="font-size:11px"></i>Admin</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">New This Month</div>
    <div class="stat-val">{{ number_format($newThisMonth) }}</div>
    <span class="badge badge-new"><i class="ti ti-arrow-up" style="font-size:11px"></i>This month</span>
  </div>
</div>

{{-- Table card --}}
<div class="card">
  <div class="card-header">
    <div class="card-title">All Users</div>
    <a href="{{ route('users.create') }}" class="btn btn-primary">
      <i class="ti ti-plus" style="font-size:15px"></i>Add User
    </a>
  </div>

  <div class="search-bar">
    <i class="ti ti-search"></i>
    <input type="text" id="userSearch" placeholder="Search by name or email…">
  </div>

  @if($users->count())
  <table class="data-table" id="userTable">
    <thead>
      <tr>
        <th>User</th>
        <th>Email</th>
        <th>Role</th>
        <th>Joined</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      @php
        $avColors = [
          ['#ff3b3022','#ff3b30'],['#36d87022','#36d870'],
          ['#ff8a9622','#ff8a96'],['rgba(255,255,255,.08)','rgba(255,255,255,.5)'],
        ];
      @endphp
      @foreach($users as $i => $u)
        @php
          $initials = strtoupper(implode('', array_map(fn($w) => $w[0], explode(' ', trim($u->name)))));
          $initials = substr($initials, 0, 2);
          [$bg, $fg] = $avColors[$i % count($avColors)];
        @endphp
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="user-av" style="background:{{ $bg }};color:{{ $fg }}">{{ $initials }}</div>
              <span style="font-weight:500">{{ $u->name }}</span>
            </div>
          </td>
          <td style="color:rgba(255,255,255,.45)">{{ $u->email }}</td>
          <td>
            <span class="badge {{ $u->role === 'admin' ? 'badge-admin' : 'badge-active' }}">
              {{ ucfirst($u->role ?? 'user') }}
            </span>
          </td>
          <td style="color:rgba(255,255,255,.35)">{{ $u->created_at->format('M d, Y') }}</td>
          <td style="text-align:right">
            <a href="{{ route('users.edit', $u) }}" class="action-btn" title="Edit">
              <i class="ti ti-pencil"></i>
            </a>
            <form method="POST" action="{{ route('users.destroy', $u) }}" style="display:inline"
                  onsubmit="return confirm('Delete {{ addslashes($u->name) }}?')">
              @csrf @method('DELETE')
              <button type="submit" class="action-btn" title="Delete">
                <i class="ti ti-trash"></i>
              </button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
  <div style="margin-top:16px">{{ $users->links() }}</div>
  @else
    <div class="empty-state">
      <i class="ti ti-users-off"></i>
      No users found.
    </div>
  @endif
</div>
@endsection

@section('scripts')
<script>
document.getElementById('userSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#userTable tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});
</script>
@endsection
