@extends('layouts.app')

@section('title', 'Tracks')

@section('styles')
<style>
.stats { display: grid; grid-template-columns: repeat(3,1fr); gap: 14px; margin-bottom: 24px; }
.stat-card { background:#161616; border:1px solid rgba(255,255,255,.07); border-radius:14px; padding:18px 20px; }
.stat-label { font-size:.72rem; color:rgba(255,255,255,.38); text-transform:uppercase; letter-spacing:.07em; margin-bottom:10px; }
.stat-val { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; letter-spacing:-.03em; margin-bottom:6px; }
.track-thumb {
  width: 40px; height: 40px; border-radius: 8px;
  background: #1e1e1e; display: flex; align-items: center;
  justify-content: center; font-size: 1rem; flex-shrink: 0; overflow: hidden;
}
.track-thumb img { width: 100%; height: 100%; object-fit: cover; }
.action-btn {
  background: none; border: none;
  color: rgba(255,255,255,.25); cursor: pointer;
  font-size: 16px; padding: 4px; border-radius: 6px;
  transition: color .18s, background .18s;
}
.action-btn:hover { color: #ff3b30; background: rgba(255,59,48,.1); }
.duration { font-family: 'Syne', sans-serif; font-size: .8rem; color: rgba(255,255,255,.3); }
@media (max-width:860px) { .stats { grid-template-columns: repeat(2,1fr); } }
</style>
@endsection

@section('content')

<div class="stats">
  <div class="stat-card">
    <div class="stat-label">Total Tracks</div>
    <div class="stat-val">{{ number_format($totalTracks) }}</div>
    <span class="badge badge-up"><i class="ti ti-music" style="font-size:11px"></i>Library</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Total Streams</div>
    <div class="stat-val">{{ $totalStreams >= 1000000 ? number_format($totalStreams/1000000,1).'M' : number_format($totalStreams/1000,1).'K' }}</div>
    <span class="badge badge-up"><i class="ti ti-player-play" style="font-size:11px"></i>All time</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Added This Month</div>
    <div class="stat-val">{{ number_format($addedThisMonth) }}</div>
    <span class="badge badge-new"><i class="ti ti-arrow-up" style="font-size:11px"></i>This month</span>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">All Tracks</div>
    <a href="{{ route('tracks.create') }}" class="btn btn-primary">
      <i class="ti ti-plus" style="font-size:15px"></i>Upload Track
    </a>
  </div>

  <div class="search-bar">
    <i class="ti ti-search"></i>
    <input type="text" id="trackSearch" placeholder="Search tracks, artists, albums…">
  </div>

  @if($tracks->count())
  <table class="data-table" id="trackTable">
    <thead>
      <tr>
        <th>#</th>
        <th>Track</th>
        <th>Artist</th>
        <th>Album</th>
        <th>Genre</th>
        <th>Plays</th>
        <th>Duration</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      @foreach($tracks as $i => $t)
        @php
          $plays = $t->plays >= 1000000
            ? number_format($t->plays/1000000,1).'M'
            : ($t->plays >= 1000 ? number_format($t->plays/1000,1).'K' : $t->plays);
          $mins = isset($t->duration) ? floor($t->duration/60).':'.str_pad($t->duration%60,2,'0',STR_PAD_LEFT) : '—';
        @endphp
        <tr>
          <td style="color:rgba(255,255,255,.2);font-size:.75rem">{{ $tracks->firstItem() + $i }}</td>
          <td>
            <div style="display:flex;align-items:center;gap:10px">
              <div class="track-thumb"
                   data-title="{{ $t->title }}"
                   data-artist="{{ $t->artist }}">🎵</div>
              <span style="font-weight:500">{{ $t->title }}</span>
            </div>
          </td>
          <td style="color:rgba(255,255,255,.45)">{{ $t->artist }}</td>
          <td style="color:rgba(255,255,255,.35)">{{ $t->album ?? '—' }}</td>
          <td>
            @if($t->genre)
              <span class="badge badge-info">{{ $t->genre }}</span>
            @else
              <span style="color:rgba(255,255,255,.2)">—</span>
            @endif
          </td>
          <td style="color:rgba(255,255,255,.4)">{{ $plays }}</td>
          <td class="duration">{{ $mins }}</td>
          <td style="text-align:right">
            <a href="{{ route('tracks.edit', $t) }}" class="action-btn" title="Edit">
              <i class="ti ti-pencil"></i>
            </a>
            <form method="POST" action="{{ route('tracks.destroy', $t) }}" style="display:inline"
                  onsubmit="return confirm('Delete {{ addslashes($t->title) }}?')">
              @csrf @method('DELETE')
              <button type="submit" class="action-btn" title="Delete">
                <i class="ti ti-trash"></i>
              </button>
            </form>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
  <div style="margin-top:16px">{{ $tracks->links() }}</div>
  @else
    <div class="empty-state">
      <i class="ti ti-music-off"></i>
      No tracks uploaded yet.
    </div>
  @endif
</div>
@endsection

@section('scripts')
<script>
// Live search filter
document.getElementById('trackSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('#trackTable tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});

// iTunes album art
document.querySelectorAll('.track-thumb[data-title]').forEach(function (el) {
  const query = encodeURIComponent(el.dataset.title + ' ' + el.dataset.artist);
  fetch('https://itunes.apple.com/search?term=' + query + '&media=music&limit=1')
    .then(r => r.json())
    .then(data => {
      if (data.results?.length) {
        const art = data.results[0].artworkUrl100.replace('100x100bb','80x80bb');
        el.innerHTML = `<img src="${art}" alt="">`;
      }
    }).catch(() => {});
});
</script>
@endsection
