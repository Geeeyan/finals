@extends('layouts.app')

@section('title', 'Reports')

@section('styles')
<style>
.stats { display: grid; grid-template-columns: repeat(4,1fr); gap: 14px; margin-bottom: 24px; }
.stat-card { background:#161616; border:1px solid rgba(255,255,255,.07); border-radius:14px; padding:18px 20px; }
.stat-label { font-size:.72rem; color:rgba(255,255,255,.38); text-transform:uppercase; letter-spacing:.07em; margin-bottom:10px; }
.stat-val { font-family:'Syne',sans-serif; font-size:1.7rem; font-weight:800; letter-spacing:-.03em; margin-bottom:6px; }
.report-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 14px; margin-bottom: 20px; }
.chart-bars { display:flex; align-items:flex-end; gap:6px; height:140px; margin-bottom:12px; }
.bar-wrap { flex:1; display:flex; flex-direction:column; align-items:center; gap:6px; height:100%; }
.bar { width:100%; border-radius:4px 4px 0 0; min-height:4px; }
.bar-lbl { font-size:.68rem; color:rgba(255,255,255,.3); }
.top-row {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 8px; border-radius: 10px;
  transition: background .18s;
}
.top-row:hover { background: rgba(255,255,255,.04); }
.rank-num { font-size:.75rem; color:rgba(255,255,255,.2); width:16px; text-align:center; flex-shrink:0; }
.rank-info { flex: 1; min-width: 0; }
.rank-name { font-size:.85rem; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.rank-sub { font-size:.72rem; color:rgba(255,255,255,.35); margin-top:2px; }
.rank-val { font-size:.78rem; color:rgba(255,255,255,.3); flex-shrink:0; }
.genre-row { display:flex; align-items:center; gap:12px; margin-bottom:14px; }
.genre-label { font-size:.78rem; color:rgba(255,255,255,.5); width:80px; flex-shrink:0; }
.genre-bar-bg { flex:1; height:6px; background:rgba(255,255,255,.07); border-radius:3px; overflow:hidden; }
.genre-bar-fill { height:100%; border-radius:3px; }
.genre-pct { font-size:.72rem; color:rgba(255,255,255,.3); width:34px; text-align:right; }
@media (max-width:900px) {
  .stats { grid-template-columns:repeat(2,1fr); }
  .report-grid { grid-template-columns:1fr; }
}
</style>
@endsection

@section('content')

<div class="stats">
  <div class="stat-card">
    <div class="stat-label">Total Streams</div>
    <div class="stat-val">{{ $totalStreams >= 1000000 ? number_format($totalStreams/1000000,1).'M' : number_format($totalStreams/1000,1).'K' }}</div>
    <span class="badge badge-up"><i class="ti ti-arrow-up" style="font-size:11px"></i>All time</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Streams Today</div>
    <div class="stat-val">{{ number_format($streamsToday) }}</div>
    <span class="badge badge-up"><i class="ti ti-arrow-up" style="font-size:11px"></i>Today</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Avg. Daily</div>
    <div class="stat-val">{{ number_format($avgDaily) }}</div>
    <span class="badge badge-info"><i class="ti ti-chart-line" style="font-size:11px"></i>7-day avg</span>
  </div>
  <div class="stat-card">
    <div class="stat-label">Active Users</div>
    <div class="stat-val">{{ number_format($activeUsers) }}</div>
    <span class="badge badge-active"><i class="ti ti-users" style="font-size:11px"></i>This week</span>
  </div>
</div>

<div class="report-grid">
  {{-- Weekly chart --}}
  <div class="card">
    <div class="card-header">
      <div class="card-title">Weekly Streams</div>
    </div>
    <div class="chart-bars" id="chartBars"></div>
    <div style="display:flex;gap:16px">
      <div style="display:flex;align-items:center;gap:6px;font-size:.75rem;color:rgba(255,255,255,.4)">
        <div style="width:8px;height:8px;border-radius:50%;background:#ff3b30"></div>This week
      </div>
    </div>
  </div>

  {{-- Top tracks --}}
  <div class="card">
    <div class="card-header">
      <div class="card-title">Top Tracks</div>
    </div>
    @forelse($topTracks as $i => $t)
      @php
        $plays = $t->plays >= 1000000
          ? number_format($t->plays/1000000,1).'M'
          : ($t->plays >= 1000 ? number_format($t->plays/1000,1).'K' : $t->plays);
      @endphp
      <div class="top-row">
        <div class="rank-num">{{ $i+1 }}</div>
        <div class="rank-info">
          <div class="rank-name">{{ $t->title }}</div>
          <div class="rank-sub">{{ $t->artist }}</div>
        </div>
        <div class="rank-val">{{ $plays }}</div>
      </div>
    @empty
      <div class="empty-state" style="padding:30px 0">
        <i class="ti ti-music-off"></i>No data yet.
      </div>
    @endforelse
  </div>
</div>

{{-- Genre breakdown --}}
<div class="card">
  <div class="card-header">
    <div class="card-title">Genre Breakdown</div>
  </div>
  @php $genreColors = ['#ff3b30','#ff6b35','#36d870','#5c7cfa','#845ef7','#ff8a96']; @endphp
  @php $totalGenre = $genres->sum('cnt') ?: 1; @endphp
  @forelse($genres as $i => $g)
    @php $pct = round(($g->cnt / $totalGenre) * 100); @endphp
    <div class="genre-row">
      <div class="genre-label">{{ $g->genre }}</div>
      <div class="genre-bar-bg">
        <div class="genre-bar-fill"
             style="width:{{ $pct }}%;background:{{ $genreColors[$i % count($genreColors)] }}"></div>
      </div>
      <div class="genre-pct">{{ $pct }}%</div>
    </div>
  @empty
    <p style="font-size:.82rem;color:rgba(255,255,255,.3)">No genre data yet.</p>
  @endforelse
</div>
@endsection

@section('scripts')
<script>
const weekDays   = @json($weekDays);
const weekCounts = @json($weekCounts);
const maxVal = Math.max(...weekCounts, 1);
const container = document.getElementById('chartBars');
weekDays.forEach((day, i) => {
  const heightPct = Math.round((weekCounts[i] / maxVal) * 100);
  const wrap = document.createElement('div');
  wrap.className = 'bar-wrap';
  wrap.innerHTML = `
    <div style="display:flex;flex-direction:column;width:100%;align-items:center;flex:1;justify-content:flex-end">
      <div class="bar" style="height:${heightPct}%;background:#ff3b30;transition:height .5s cubic-bezier(.16,1,.3,1)"></div>
    </div>
    <div class="bar-lbl">${day}</div>
  `;
  container.appendChild(wrap);
});
</script>
@endsection
