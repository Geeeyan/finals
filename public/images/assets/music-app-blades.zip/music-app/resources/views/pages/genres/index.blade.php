@extends('layouts.app')

@section('title', 'Genres')

@section('styles')
<style>
.genre-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 14px;
  margin-top: 20px;
}
.genre-card {
  border-radius: 14px;
  padding: 20px;
  position: relative;
  overflow: hidden;
  cursor: pointer;
  transition: transform .2s, box-shadow .2s;
  min-height: 110px;
  display: flex; flex-direction: column; justify-content: space-between;
}
.genre-card:hover { transform: translateY(-2px); box-shadow: 0 8px 32px rgba(0,0,0,.4); }
.genre-card-name {
  font-family: 'Syne', sans-serif; font-size: 1.1rem; font-weight: 800;
  letter-spacing: -.02em; position: relative; z-index: 1;
}
.genre-card-count {
  font-size: .75rem; opacity: .7; position: relative; z-index: 1;
  margin-top: 6px;
}
.genre-card-icon {
  position: absolute; right: 16px; top: 50%;
  transform: translateY(-50%);
  font-size: 3rem; opacity: .15;
}
.genre-card-actions {
  display: flex; gap: 4px;
  position: absolute; bottom: 12px; right: 12px; z-index: 2;
  opacity: 0; transition: opacity .18s;
}
.genre-card:hover .genre-card-actions { opacity: 1; }
.action-btn {
  background: rgba(0,0,0,.3); backdrop-filter: blur(6px);
  border: none; border-radius: 6px;
  color: rgba(255,255,255,.8); cursor: pointer;
  font-size: 14px; padding: 5px 7px;
  transition: color .18s, background .18s;
}
.action-btn:hover { background: rgba(0,0,0,.6); color: #fff; }
.pct-bar {
  height: 3px; border-radius: 2px;
  background: rgba(255,255,255,.15);
  margin-top: 10px; overflow: hidden;
}
.pct-bar-fill { height: 100%; border-radius: 2px; background: rgba(255,255,255,.5); }
</style>
@endsection

@section('content')

@php
  $palettes = [
    ['#ff3b30','#cc1a10'],['#ff6b35','#e84b15'],
    ['#36d870','#22a854'],['#5c7cfa','#3b5bdb'],
    ['#845ef7','#6741d9'],['#ff8a96','#e0606c'],
    ['#fab005','#e67700'],['#20c997','#0ca678'],
    ['#fd7e14','#e8590c'],['#74c0fc','#4dabf7'],
  ];
  $icons = ['🎸','🎹','🎤','🥁','🎻','🎷','🎺','🎧','🎼','🎙️'];
  $total = $genres->sum('tracks_count') ?: 1;
@endphp

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px">
  <div class="search-bar" style="margin-bottom:0;width:280px">
    <i class="ti ti-search"></i>
    <input type="text" id="genreSearch" placeholder="Search genres…">
  </div>
  <a href="{{ route('genres.create') }}" class="btn btn-primary">
    <i class="ti ti-plus" style="font-size:15px"></i>Add Genre
  </a>
</div>

@if($genres->count())
  <div class="genre-grid" id="genreGrid">
    @foreach($genres as $i => $genre)
      @php
        [$c1,$c2] = $palettes[$i % count($palettes)];
        $icon = $icons[$i % count($icons)];
        $pct = round(($genre->tracks_count / $total) * 100);
      @endphp
      <div class="genre-card"
           style="background: linear-gradient(135deg, {{ $c1 }}, {{ $c2 }})"
           data-search="{{ strtolower($genre->name) }}">
        <div>
          <div class="genre-card-name">{{ $genre->name }}</div>
          <div class="genre-card-count">{{ number_format($genre->tracks_count) }} tracks</div>
          <div class="pct-bar">
            <div class="pct-bar-fill" style="width:{{ $pct }}%"></div>
          </div>
        </div>
        <div class="genre-card-icon">{{ $icon }}</div>
        <div class="genre-card-actions">
          <a href="{{ route('genres.edit', $genre) }}" class="action-btn" title="Edit">
            <i class="ti ti-pencil"></i>
          </a>
          <form method="POST" action="{{ route('genres.destroy', $genre) }}"
                style="display:inline"
                onsubmit="return confirm('Delete {{ addslashes($genre->name) }}?')">
            @csrf @method('DELETE')
            <button type="submit" class="action-btn" title="Delete">
              <i class="ti ti-trash"></i>
            </button>
          </form>
        </div>
      </div>
    @endforeach
  </div>
@else
  <div class="empty-state">
    <i class="ti ti-tag-off"></i>
    No genres yet.
  </div>
@endif
@endsection

@section('scripts')
<script>
document.getElementById('genreSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.genre-card').forEach(card => {
    card.style.display = card.dataset.search.includes(q) ? '' : 'none';
  });
});
</script>
@endsection
