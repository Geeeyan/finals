<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MUS.IC — @yield('title', 'Dashboard')</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.44.0/tabler-icons.min.css">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'Inter', sans-serif;
  background: #0a0a0a;
  color: #fff;
  min-height: 100vh;
  display: flex;
}

/* ── Sidebar ── */
.sidebar {
  width: 220px;
  background: #111;
  border-right: 1px solid rgba(255,255,255,.07);
  display: flex;
  flex-direction: column;
  padding: 24px 16px;
  gap: 4px;
  flex-shrink: 0;
  position: sticky;
  top: 0;
  height: 100vh;
}

.logo {
  font-family: 'Syne', sans-serif;
  font-size: 1.4rem;
  font-weight: 800;
  color: #ff3b30;
  letter-spacing: -.03em;
  padding: 0 8px;
  margin-bottom: 24px;
}

.nav-section {
  font-size: .65rem;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: rgba(255,255,255,.2);
  padding: 16px 12px 6px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 10px;
  font-size: .85rem;
  font-weight: 500;
  color: rgba(255,255,255,.45);
  cursor: pointer;
  text-decoration: none;
  transition: background .18s, color .18s;
}

.nav-item i { font-size: 17px; }
.nav-item:hover  { background: rgba(255,255,255,.05); color: rgba(255,255,255,.75); }
.nav-item.active { background: #ff3b30; color: #ffffff; }
.nav-item.logout { color: rgba(220,53,69,.7); }
.nav-item.logout:hover { background: rgba(220,53,69,.08); color: #ff8a96; }

/* ── Main ── */
.main {
  flex: 1;
  overflow-y: auto;
  padding: 28px 32px;
}

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 28px;
}

.page-title {
  font-family: 'Syne', sans-serif;
  font-size: 1.5rem;
  font-weight: 800;
  letter-spacing: -.02em;
}

.topbar-right { display: flex; align-items: center; gap: 12px; }

.notif-btn {
  width: 36px; height: 36px;
  border-radius: 10px;
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.08);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  color: rgba(255,255,255,.5);
  position: relative;
}

.notif-dot {
  width: 7px; height: 7px;
  background: #ff3b30;
  border-radius: 50%;
  position: absolute;
  top: 6px; right: 6px;
}

.admin-pill {
  display: flex; align-items: center; gap: 8px;
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 10px;
  padding: 6px 12px 6px 6px;
  font-size: .82rem;
  color: rgba(255,255,255,.7);
  text-decoration: none;
}

.avatar-sm {
  width: 26px; height: 26px;
  border-radius: 50%;
  background: #ff3b30;
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; font-weight: 700;
}

/* ── Shared card ── */
.card {
  background: #161616;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  padding: 20px;
}

.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 18px;
}

.card-title {
  font-family: 'Syne', sans-serif;
  font-size: .95rem;
  font-weight: 700;
}

.card-action {
  font-size: .78rem;
  color: rgba(255,255,255,.3);
  text-decoration: none;
  transition: color .2s;
}
.card-action:hover { color: #ff3b30; }

/* ── Badge ── */
.badge {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: .72rem; padding: 3px 8px; border-radius: 6px;
}
.badge-up     { background: rgba(30,200,90,.12);  color: #36d870; }
.badge-new    { background: rgba(255,59,48,.10);  color: #ff3b30; }
.badge-active { background: rgba(30,200,90,.12);  color: #36d870; }
.badge-admin  { background: rgba(255,59,48,.12);  color: #ff3b30; }
.badge-info   { background: rgba(100,160,255,.12); color: #64a0ff; }

/* ── Search bar ── */
.search-bar {
  display: flex; align-items: center; gap: 10px;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 10px;
  padding: 9px 14px;
  margin-bottom: 20px;
}
.search-bar i { color: rgba(255,255,255,.25); font-size: 16px; }
.search-bar input {
  background: none; border: none; outline: none;
  color: #fff; font-size: .85rem; width: 100%;
}
.search-bar input::placeholder { color: rgba(255,255,255,.2); }

/* ── Data table ── */
.data-table { width: 100%; border-collapse: collapse; }
.data-table th {
  font-size: .68rem; letter-spacing: .08em; text-transform: uppercase;
  color: rgba(255,255,255,.25); font-weight: 500;
  padding: 0 12px 12px; text-align: left;
}
.data-table td {
  padding: 11px 12px;
  font-size: .83rem;
  border-top: 1px solid rgba(255,255,255,.05);
  vertical-align: middle;
}
.data-table tr:hover td { background: rgba(255,255,255,.02); }

/* ── Empty state ── */
.empty-state {
  display: flex; flex-direction: column; align-items: center;
  justify-content: center; gap: 12px;
  padding: 60px 20px;
  color: rgba(255,255,255,.2);
  font-size: .85rem;
}
.empty-state i { font-size: 2.5rem; opacity: .3; }

/* ── Btn ── */
.btn {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 9px 16px; border-radius: 10px;
  font-size: .82rem; font-weight: 500;
  cursor: pointer; border: none; text-decoration: none;
  transition: opacity .18s, transform .1s;
}
.btn:active { transform: scale(.97); }
.btn-primary { background: #ff3b30; color: #fff; }
.btn-primary:hover { opacity: .88; }
.btn-ghost {
  background: rgba(255,255,255,.06);
  border: 1px solid rgba(255,255,255,.08);
  color: rgba(255,255,255,.6);
}
.btn-ghost:hover { background: rgba(255,255,255,.1); color: #fff; }

/* ── Responsive ── */
@media (max-width: 640px) {
  body { flex-direction: column; }
  .sidebar {
    width: 100%; height: auto;
    flex-direction: row; flex-wrap: wrap;
    padding: 12px; position: relative;
  }
  .logo { margin-bottom: 0; width: 100%; }
  .nav-section { display: none; }
  .main { padding: 16px; }
}

@yield('styles')
</style>
</head>
<body>

{{-- ── Sidebar ── --}}
<div class="sidebar">
  <div class="logo">MUS.IC</div>

  <a href="{{ route('dashboard') }}"
     class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
    <i class="ti ti-layout-dashboard"></i>Dashboard
  </a>
  <a href="{{ route('users.index') }}"
     class="nav-item {{ request()->routeIs('users.*') ? 'active' : '' }}">
    <i class="ti ti-users"></i>Users
  </a>
  <a href="{{ route('tracks.index') }}"
     class="nav-item {{ request()->routeIs('tracks.*') ? 'active' : '' }}">
    <i class="ti ti-music"></i>Tracks
  </a>
  <a href="{{ route('playlists.index') }}"
     class="nav-item {{ request()->routeIs('playlists.*') ? 'active' : '' }}">
    <i class="ti ti-playlist"></i>Playlists
  </a>

  <div class="nav-section">Library</div>
  <a href="{{ route('albums.index') }}"
     class="nav-item {{ request()->routeIs('albums.*') ? 'active' : '' }}">
    <i class="ti ti-vinyl"></i>Albums
  </a>
  <a href="{{ route('artists.index') }}"
     class="nav-item {{ request()->routeIs('artists.*') ? 'active' : '' }}">
    <i class="ti ti-music-star"></i>Artists
  </a>
  <a href="{{ route('genres.index') }}"
     class="nav-item {{ request()->routeIs('genres.*') ? 'active' : '' }}">
    <i class="ti ti-tag"></i>Genres
  </a>

  <div class="nav-section">Analytics</div>
  <a href="{{ route('reports.index') }}"
     class="nav-item {{ request()->routeIs('reports.*') ? 'active' : '' }}">
    <i class="ti ti-chart-bar"></i>Reports
  </a>

  <div class="nav-section">System</div>
  <a href="{{ route('settings.index') }}"
     class="nav-item {{ request()->routeIs('settings.*') ? 'active' : '' }}">
    <i class="ti ti-settings"></i>Settings
  </a>

  <div style="flex:1"></div>

  <form method="POST" action="{{ route('logout') }}">
    @csrf
    <button type="submit" class="nav-item logout"
            style="width:100%;border:none;background:none;cursor:pointer;">
      <i class="ti ti-logout"></i>Logout
    </button>
  </form>
</div>

{{-- ── Main ── --}}
<div class="main">
  <div class="topbar">
    <div class="page-title">@yield('title', 'Dashboard')</div>
    <div class="topbar-right">
      <div class="notif-btn">
        <i class="ti ti-bell" style="font-size:16px"></i>
        <div class="notif-dot"></div>
      </div>
      <a href="{{ route('profile.edit') }}" class="admin-pill">
        <div class="avatar-sm">{{ strtoupper(substr(Auth::user()->name, 0, 2)) }}</div>
        {{ Auth::user()->name }}
      </a>
    </div>
  </div>

  @yield('content')
</div>

@include('partials.toast')

@yield('scripts')
</body>
</html>
